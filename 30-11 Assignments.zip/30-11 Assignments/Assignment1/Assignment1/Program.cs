﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {

        String[] arr = new String[] { "Aman", "Piyanshu", "Sameer", "Vaishu", "Komal", "Deepak", "Vedant", "Kiran","bcd" };
        static void Main(string[] args)
        {
            Program p = new Program();
            //Console.WriteLine("Enter name you want to search...");
            //String name = Console.ReadLine();

            // without using contains method...
            //int result = p.Searchname(name);

            //if(result==-1)
            //{
            //    Console.WriteLine("Sorry name not found....");
            //}
            //else
            //{
            //    Console.WriteLine("name found at index " + result);
            //}

            // find name by using contains method...
            //if(p.arr.Contains(name))
            //{
            //    Console.WriteLine("name found...");
            //}
            //else
            //{
            //    Console.WriteLine("name not found...");
            //}

            //p.SearchWithletter();

            p.oddlength();
        }

        int  Searchname(String name)
        {
            int result = -1;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == name)
                {
                    result =  i;
                    break;
                }
                else
                {
                    result =  -1;
                }
            }
            return result;
        }

        void SearchWithletter()
        {
            int count = 0;
            //String start with 'a' letter...
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Contains('a') || arr[i].Contains('A'))
                {
                    count++;
                }
            }
            Console.WriteLine("count of string containing 'a' letter is: " + count);
        }

        void oddlength()
        {
            int count = 0;
            for(int i=0;i<arr.Length;i++)
            {
                if(arr[i].Length%2==1)
                {
                    count++;
                }
            }
            Console.WriteLine("odd length string count is..."+count);
        }
    }
}
